import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Info, ArrowRight } from 'lucide-react';

const SortingVisualizer = () => {
  const [array, setArray] = useState([64, 34, 25, 12, 22, 11, 90]);
  const [inputValue, setInputValue] = useState('64, 34, 25, 12, 22, 11, 90');
  const [algorithm, setAlgorithm] = useState('bubble');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [steps, setSteps] = useState([]);
  const [speed, setSpeed] = useState(500);

  const algorithms = {
    bubble: {
      name: 'Bubble Sort',
      description: 'Compares adjacent elements and swaps them if they are in wrong order. The largest element "bubbles up" to its correct position in each pass.',
      complexity: 'Time: O(n²) | Space: O(1)',
      bestFor: 'Small datasets, educational purposes',
      generate: (arr) => {
        const steps = [];
        const a = [...arr];
        steps.push({ array: [...a], comparing: [], swapping: [], sorted: [], message: 'Starting Bubble Sort...', iteration: 0 });

        for (let i = 0; i < a.length - 1; i++) {
          steps.push({ array: [...a], comparing: [], swapping: [], sorted: [], message: `Pass ${i + 1}: Finding largest unsorted element`, iteration: i + 1 });

          for (let j = 0; j < a.length - i - 1; j++) {
            steps.push({ array: [...a], comparing: [j, j + 1], swapping: [], sorted: Array.from({ length: i }, (_, k) => a.length - k - 1), message: `Comparing ${a[j]} and ${a[j + 1]}`, iteration: i + 1 });

            if (a[j] > a[j + 1]) {
              steps.push({ array: [...a], comparing: [], swapping: [j, j + 1], sorted: Array.from({ length: i }, (_, k) => a.length - k - 1), message: `Swapping ${a[j]} and ${a[j + 1]}`, iteration: i + 1 });
              [a[j], a[j + 1]] = [a[j + 1], a[j]];
              steps.push({ array: [...a], comparing: [], swapping: [], sorted: Array.from({ length: i }, (_, k) => a.length - k - 1), message: `Swapped! Array updated`, iteration: i + 1 });
            }
          }
          steps.push({ array: [...a], comparing: [], swapping: [], sorted: Array.from({ length: i + 1 }, (_, k) => a.length - k - 1), message: `${a[a.length - i - 1]} is in correct position`, iteration: i + 1 });
        }
        steps.push({ array: [...a], comparing: [], swapping: [], sorted: Array.from({ length: a.length }, (_, i) => i), message: 'Array is sorted!', iteration: 'Complete' });
        return steps;
      }
    },
    selection: {
      name: 'Selection Sort',
      description: 'Finds the minimum element from unsorted part and puts it at the beginning. Divides array into sorted and unsorted regions.',
      complexity: 'Time: O(n²) | Space: O(1)',
      bestFor: 'When memory writes are costly',
      generate: (arr) => {
        const steps = [];
        const a = [...arr];
        steps.push({ array: [...a], comparing: [], swapping: [], sorted: [], message: 'Starting Selection Sort...', iteration: 0 });

        for (let i = 0; i < a.length - 1; i++) {
          let minIdx = i;
          steps.push({ array: [...a], comparing: [i], swapping: [], sorted: Array.from({ length: i }, (_, k) => k), message: `Finding minimum in unsorted part`, iteration: i + 1 });

          for (let j = i + 1; j < a.length; j++) {
            steps.push({ array: [...a], comparing: [minIdx, j], swapping: [], sorted: Array.from({ length: i }, (_, k) => k), message: `Current min: ${a[minIdx]}, Checking: ${a[j]}`, iteration: i + 1 });
            if (a[j] < a[minIdx]) {
              minIdx = j;
              steps.push({ array: [...a], comparing: [minIdx], swapping: [], sorted: Array.from({ length: i }, (_, k) => k), message: `New minimum found: ${a[minIdx]}`, iteration: i + 1 });
            }
          }

          if (minIdx !== i) {
            steps.push({ array: [...a], comparing: [], swapping: [i, minIdx], sorted: Array.from({ length: i }, (_, k) => k), message: `Swapping ${a[i]} with minimum ${a[minIdx]}`, iteration: i + 1 });
            [a[i], a[minIdx]] = [a[minIdx], a[i]];
            steps.push({ array: [...a], comparing: [], swapping: [], sorted: Array.from({ length: i + 1 }, (_, k) => k), message: `${a[i]} placed in position ${i}`, iteration: i + 1 });
          } else {
            steps.push({ array: [...a], comparing: [], swapping: [], sorted: Array.from({ length: i + 1 }, (_, k) => k), message: `${a[i]} already in correct position`, iteration: i + 1 });
          }
        }
        steps.push({ array: [...a], comparing: [], swapping: [], sorted: Array.from({ length: a.length }, (_, i) => i), message: 'Array is sorted!', iteration: 'Complete' });
        return steps;
      }
    },
    insertion: {
      name: 'Insertion Sort',
      description: 'Builds the sorted array one element at a time by inserting each element into its correct position in the already sorted part.',
      complexity: 'Time: O(n²) | Space: O(1)',
      bestFor: 'Small or nearly sorted arrays',
      generate: (arr) => {
        const steps = [];
        const a = [...arr];
        steps.push({ array: [...a], comparing: [], swapping: [], sorted: [0], message: 'Starting Insertion Sort...', iteration: 0 });

        for (let i = 1; i < a.length; i++) {
          let key = a[i];
          let j = i - 1;
          steps.push({ array: [...a], comparing: [i], swapping: [], sorted: Array.from({ length: i }, (_, k) => k), message: `Inserting ${key} into sorted part`, iteration: i });

          while (j >= 0 && a[j] > key) {
            steps.push({ array: [...a], comparing: [j, j + 1], swapping: [], sorted: [], message: `${a[j]} > ${key}, shifting right`, iteration: i });
            a[j + 1] = a[j];
            steps.push({ array: [...a], comparing: [j], swapping: [], sorted: [], message: `Shifted ${a[j]} to position ${j + 1}`, iteration: i });
            j--;
          }
          a[j + 1] = key;
          steps.push({ array: [...a], comparing: [], swapping: [], sorted: Array.from({ length: i + 1 }, (_, k) => k), message: `Inserted ${key} at position ${j + 1}`, iteration: i });
        }
        steps.push({ array: [...a], comparing: [], swapping: [], sorted: Array.from({ length: a.length }, (_, i) => i), message: 'Array is sorted!', iteration: 'Complete' });
        return steps;
      }
    },
    quick: {
      name: 'Quick Sort',
      description: 'Uses divide-and-conquer strategy. Picks a pivot element and partitions array around it, then recursively sorts sub-arrays.',
      complexity: 'Time: O(n log n) avg | Space: O(log n)',
      bestFor: 'Large datasets, general purpose',
      generate: (arr) => {
        const steps = [];
        const a = [...arr];
        let iterationCount = 0;
        steps.push({ array: [...a], comparing: [], swapping: [], sorted: [], message: 'Starting Quick Sort...', iteration: 0 });

        const quickSort = (low, high) => {
          if (low < high) {
            const pi = partition(low, high);
            quickSort(low, pi - 1);
            quickSort(pi + 1, high);
          }
        };

        const partition = (low, high) => {
          iterationCount++;
          const pivot = a[high];
          steps.push({ array: [...a], comparing: [high], swapping: [], sorted: [], message: `Pivot selected: ${pivot}`, iteration: iterationCount });
          let i = low - 1;

          for (let j = low; j < high; j++) {
            steps.push({ array: [...a], comparing: [j, high], swapping: [], sorted: [], message: `Comparing ${a[j]} with pivot ${pivot}`, iteration: iterationCount });
            if (a[j] < pivot) {
              i++;
              if (i !== j) {
                steps.push({ array: [...a], comparing: [], swapping: [i, j], sorted: [], message: `${a[j]} < ${pivot}, swapping with ${a[i]}`, iteration: iterationCount });
                [a[i], a[j]] = [a[j], a[i]];
                steps.push({ array: [...a], comparing: [], swapping: [], sorted: [], message: `Swapped ${a[i]} and ${a[j]}`, iteration: iterationCount });
              }
            }
          }
          steps.push({ array: [...a], comparing: [], swapping: [i + 1, high], sorted: [], message: `Placing pivot ${pivot} in correct position`, iteration: iterationCount });
          [a[i + 1], a[high]] = [a[high], a[i + 1]];
          steps.push({ array: [...a], comparing: [], swapping: [], sorted: [i + 1], message: `Pivot ${a[i + 1]} is now in correct position`, iteration: iterationCount });
          return i + 1;
        };

        quickSort(0, a.length - 1);
        steps.push({ array: [...a], comparing: [], swapping: [], sorted: Array.from({ length: a.length }, (_, i) => i), message: 'Array is sorted!', iteration: 'Complete' });
        return steps;
      }
    },
    merge: {
      name: 'Merge Sort',
      description: 'Divides array into two halves, recursively sorts them, and then merges the sorted halves back together. Stable and consistent performance.',
      complexity: 'Time: O(n log n) | Space: O(n)',
      bestFor: 'Large datasets, when stability matters',
      generate: (arr) => {
        const steps = [];
        const a = [...arr];
        let iterationCount = 0;
        steps.push({
          array: [...a],
          comparing: [],
          swapping: [],
          sorted: [],
          message: 'Starting Merge Sort...',
          iteration: 0,
          mergeTree: null,
          phase: 'start'
        });

        const buildTree = (arr, depth = 0, position = 'root') => {
          if (arr.length <= 1) {
            return { values: arr, depth, position, children: null, sorted: arr };
          }

          const mid = Math.floor(arr.length / 2);
          const left = arr.slice(0, mid);
          const right = arr.slice(mid);

          return {
            values: arr,
            depth,
            position,
            children: {
              left: buildTree(left, depth + 1, 'left'),
              right: buildTree(right, depth + 1, 'right')
            },
            sorted: null
          };
        };

        const tree = buildTree([...a]);

        steps.push({
          array: [...a],
          comparing: [],
          swapping: [],
          sorted: [],
          message: 'Dividing array into smaller subarrays',
          iteration: 1,
          mergeTree: tree,
          phase: 'divide'
        });

        const merge = (left, mid, right) => {
          const leftArr = a.slice(left, mid + 1);
          const rightArr = a.slice(mid + 1, right + 1);

          iterationCount++;
          steps.push({
            array: [...a],
            comparing: Array.from({ length: right - left + 1 }, (_, i) => left + i),
            swapping: [],
            sorted: [],
            message: `Merging subarrays [${leftArr}] and [${rightArr}]`,
            iteration: iterationCount,
            mergeTree: tree,
            phase: 'merge',
            currentMerge: { left: leftArr, right: rightArr, range: [left, right] }
          });

          let i = 0, j = 0, k = left;

          while (i < leftArr.length && j < rightArr.length) {
            steps.push({
              array: [...a],
              comparing: [left + i, mid + 1 + j],
              swapping: [],
              sorted: [],
              message: `Comparing ${leftArr[i]} and ${rightArr[j]}`,
              iteration: iterationCount,
              mergeTree: tree,
              phase: 'merge',
              currentMerge: { left: leftArr, right: rightArr, range: [left, right] }
            });

            if (leftArr[i] <= rightArr[j]) {
              a[k] = leftArr[i];
              steps.push({
                array: [...a],
                comparing: [],
                swapping: [k],
                sorted: [],
                message: `Placing ${leftArr[i]} at position ${k}`,
                iteration: iterationCount,
                mergeTree: tree,
                phase: 'merge',
                currentMerge: { left: leftArr, right: rightArr, range: [left, right] }
              });
              i++;
            } else {
              a[k] = rightArr[j];
              steps.push({
                array: [...a],
                comparing: [],
                swapping: [k],
                sorted: [],
                message: `Placing ${rightArr[j]} at position ${k}`,
                iteration: iterationCount,
                mergeTree: tree,
                phase: 'merge',
                currentMerge: { left: leftArr, right: rightArr, range: [left, right] }
              });
              j++;
            }
            k++;
          }

          while (i < leftArr.length) {
            a[k] = leftArr[i];
            steps.push({
              array: [...a],
              comparing: [],
              swapping: [k],
              sorted: [],
              message: `Placing remaining ${leftArr[i]} at position ${k}`,
              iteration: iterationCount,
              mergeTree: tree,
              phase: 'merge',
              currentMerge: { left: leftArr, right: rightArr, range: [left, right] }
            });
            i++;
            k++;
          }

          while (j < rightArr.length) {
            a[k] = rightArr[j];
            steps.push({
              array: [...a],
              comparing: [],
              swapping: [k],
              sorted: [],
              message: `Placing remaining ${rightArr[j]} at position ${k}`,
              iteration: iterationCount,
              mergeTree: tree,
              phase: 'merge',
              currentMerge: { left: leftArr, right: rightArr, range: [left, right] }
            });
            j++;
            k++;
          }

          const merged = a.slice(left, right + 1);
          steps.push({
            array: [...a],
            comparing: [],
            swapping: [],
            sorted: Array.from({ length: right - left + 1 }, (_, i) => left + i),
            message: `Merged result: [${merged}]`,
            iteration: iterationCount,
            mergeTree: tree,
            phase: 'merge',
            currentMerge: { left: leftArr, right: rightArr, range: [left, right], result: merged }
          });
        };

        const mergeSort = (left, right) => {
          if (left < right) {
            const mid = Math.floor((left + right) / 2);
            mergeSort(left, mid);
            mergeSort(mid + 1, right);
            merge(left, mid, right);
          }
        };

        mergeSort(0, a.length - 1);
        steps.push({
          array: [...a],
          comparing: [],
          swapping: [],
          sorted: Array.from({ length: a.length }, (_, i) => i),
          message: 'Array is sorted!',
          iteration: 'Complete',
          mergeTree: tree,
          phase: 'complete'
        });
        return steps;
      }
    }
  };

  useEffect(() => {
    setSteps(algorithms[algorithm].generate(array));
    setCurrentStep(0);
    setIsPlaying(false);
  }, [array, algorithm]);

  useEffect(() => {
    let interval;
    if (isPlaying && currentStep < steps.length - 1) {
      interval = setInterval(() => {
        setCurrentStep(prev => prev + 1);
      }, speed);
    } else if (currentStep >= steps.length - 1) {
      setIsPlaying(false);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentStep, steps.length, speed]);

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleArraySubmit = () => {
    const newArray = inputValue.split(',').map(num => parseInt(num.trim())).filter(num => !isNaN(num));
    if (newArray.length > 0 && newArray.length <= 12) {
      setArray(newArray);
    } else {
      alert('Please enter 1-12 numbers');
    }
  };

  const handleReset = () => {
    setCurrentStep(0);
    setIsPlaying(false);
  };

  const currentState = steps[currentStep] || { array, comparing: [], swapping: [], sorted: [], message: '', iteration: 0 };
  const maxValue = Math.max(...currentState.array);

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-200 via-blue-100 to-indigo-200 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-indigo-900 mb-3 tracking-tight">Balloon Sorting Visualizer</h1>
          <p className="text-indigo-700 text-lg">Watch balloons float as they sort!</p>
        </div>

        <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-2xl p-8 mb-6 border-2 border-indigo-200">
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div>
              <label className="block text-sm font-semibold text-indigo-900 mb-2">Input Array (max 12 numbers)</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputValue}
                  onChange={handleInputChange}
                  className="flex-1 px-4 py-3 bg-white border-2 border-indigo-300 rounded-xl focus:ring-4 focus:ring-indigo-400 focus:border-transparent text-gray-800"
                  placeholder="e.g., 64, 34, 25, 12, 22"
                />
                <button
                  onClick={handleArraySubmit}
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-blue-600 text-white rounded-xl hover:from-indigo-700 hover:to-blue-700 transition-all font-semibold shadow-lg"
                >
                  Set
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-indigo-900 mb-2">Select Algorithm</label>
              <select
                value={algorithm}
                onChange={(e) => setAlgorithm(e.target.value)}
                className="w-full px-4 py-3 bg-white border-2 border-indigo-300 rounded-xl focus:ring-4 focus:ring-indigo-400 focus:border-transparent text-gray-800 font-medium"
              >
                {Object.entries(algorithms).map(([key, algo]) => (
                  <option key={key} value={key}>{algo.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 mb-6">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all font-semibold shadow-lg"
            >
              {isPlaying ? <Pause size={20} /> : <Play size={20} />}
              {isPlaying ? 'Pause' : 'Play'}
            </button>
            <button
              onClick={handleReset}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-gray-600 to-gray-700 text-white rounded-xl hover:from-gray-700 hover:to-gray-800 transition-all font-semibold shadow-lg"
            >
              <RotateCcw size={20} />
              Reset
            </button>
            <div className="flex items-center gap-3 flex-1 min-w-48">
              <label className="text-sm font-semibold text-indigo-900 whitespace-nowrap">Speed:</label>
              <input
                type="range"
                min="100"
                max="1000"
                step="100"
                value={speed}
                onChange={(e) => setSpeed(1100 - parseInt(e.target.value))}
                className="flex-1"
              />
            </div>
            <span className="text-sm font-semibold text-indigo-900 bg-indigo-100 px-4 py-2 rounded-lg border-2 border-indigo-300">
              Step: {currentStep + 1} / {steps.length}
            </span>
          </div>

          <div className="mb-6 text-center">
            <div className="inline-block bg-gradient-to-r from-blue-500 to-sky-500 text-white px-6 py-3 rounded-xl shadow-lg font-bold text-lg">
              Iteration: {currentState.iteration}
            </div>
          </div>

          <div className="bg-gradient-to-b from-sky-100 to-sky-50 rounded-2xl p-8 mb-6 min-h-96 flex flex-col justify-end items-center border-2 border-sky-200 relative overflow-hidden">
            <div className="absolute top-4 left-10 w-20 h-12 bg-white/70 rounded-full blur-sm"></div>
            <div className="absolute top-8 right-20 w-24 h-14 bg-white/60 rounded-full blur-sm"></div>
            <div className="absolute top-12 left-1/3 w-16 h-10 bg-white/50 rounded-full blur-sm"></div>

            {algorithm === 'merge' && currentState.mergeTree && currentState.phase !== 'start' ? (
              <div className="w-full flex flex-col items-center justify-center mb-8 space-y-8 py-8">
                <div className="text-center mb-4">
                  <h3 className="text-2xl font-bold text-indigo-900 mb-2">
                    {currentState.phase === 'divide' ? 'Divide & Conquer' : currentState.phase === 'merge' ? 'Merging' : 'Complete'}
                  </h3>
                </div>

                <div className="flex flex-col items-center">
                  <div className="text-sm font-semibold text-gray-600 mb-2">Unsorted Array</div>
                  <div className="flex shadow-lg rounded-lg overflow-hidden border-2 border-indigo-500">
                    {currentState.mergeTree.values.map((val, i) => (
                      <div key={i} className="w-16 h-16 bg-indigo-500 flex items-center justify-center font-bold text-white text-xl border-r border-indigo-400 last:border-r-0">
                        {val}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="text-4xl text-indigo-500">↓</div>

                {currentState.mergeTree.children && (
                  <>
                    <div className="flex gap-16">
                      <div className="flex flex-col items-center">
                        <div className="flex shadow-lg rounded-lg overflow-hidden border-2 border-blue-500">
                          {currentState.mergeTree.children.left.values.map((val, i) => (
                            <div key={i} className="w-16 h-16 bg-blue-500 flex items-center justify-center font-bold text-white text-xl border-r border-blue-400 last:border-r-0">
                              {val}
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="flex flex-col items-center">
                        <div className="flex shadow-lg rounded-lg overflow-hidden border-2 border-blue-500">
                          {currentState.mergeTree.children.right.values.map((val, i) => (
                            <div key={i} className="w-16 h-16 bg-blue-500 flex items-center justify-center font-bold text-white text-xl border-r border-blue-400 last:border-r-0">
                              {val}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {currentState.mergeTree.children.left.children && (
                      <>
                        <div className="flex gap-4">
                          <div className="text-4xl text-blue-500">↓</div>
                          <div className="w-32"></div>
                          <div className="text-4xl text-blue-500">↓</div>
                        </div>

                        <div className="flex gap-8">
                          <div className="flex shadow-lg rounded-lg overflow-hidden border-2 border-sky-400">
                            {currentState.mergeTree.children.left.children.left.values.map((val, i) => (
                              <div key={i} className="w-14 h-14 bg-sky-400 flex items-center justify-center font-bold text-white text-lg border-r border-sky-300 last:border-r-0">
                                {val}
                              </div>
                            ))}
                          </div>

                          <div className="flex shadow-lg rounded-lg overflow-hidden border-2 border-sky-400">
                            {currentState.mergeTree.children.left.children.right.values.map((val, i) => (
                              <div key={i} className="w-14 h-14 bg-sky-400 flex items-center justify-center font-bold text-white text-lg border-r border-sky-300 last:border-r-0">
                                {val}
                              </div>
                            ))}
                          </div>

                          <div className="flex shadow-lg rounded-lg overflow-hidden border-2 border-sky-400">
                            {currentState.mergeTree.children.right.children.left.values.map((val, i) => (
                              <div key={i} className="w-14 h-14 bg-sky-400 flex items-center justify-center font-bold text-white text-lg border-r border-sky-300 last:border-r-0">
                                {val}
                              </div>
                            ))}
                          </div>

                          <div className="flex shadow-lg rounded-lg overflow-hidden border-2 border-sky-400">
                            {currentState.mergeTree.children.right.children.right.values.map((val, i) => (
                              <div key={i} className="w-14 h-14 bg-sky-400 flex items-center justify-center font-bold text-white text-lg border-r border-sky-300 last:border-r-0">
                                {val}
                              </div>
                            ))}
                          </div>
                        </div>
                      </>
                    )}

                    {currentState.phase === 'merge' && currentState.currentMerge && (
                      <>
                        <div className="text-4xl text-green-500">↓</div>
                        <div className="bg-yellow-50 border-3 border-yellow-400 rounded-2xl p-6 shadow-xl">
                          <div className="text-center mb-3 font-bold text-yellow-800 text-lg">Merging Now</div>
                          <div className="flex items-center gap-4">
                            <div className="flex shadow-lg rounded-lg overflow-hidden border-2 border-blue-400">
                              {currentState.currentMerge.left.map((val, i) => (
                                <div key={i} className="w-12 h-12 bg-blue-400 flex items-center justify-center font-bold text-white text-lg border-r border-blue-300 last:border-r-0">
                                  {val}
                                </div>
                              ))}
                            </div>
                            <span className="text-3xl font-bold text-yellow-600">+</span>
                            <div className="flex shadow-lg rounded-lg overflow-hidden border-2 border-blue-400">
                              {currentState.currentMerge.right.map((val, i) => (
                                <div key={i} className="w-12 h-12 bg-blue-400 flex items-center justify-center font-bold text-white text-lg border-r border-blue-300 last:border-r-0">
                                  {val}
                                </div>
                              ))}
                            </div>
                            {currentState.currentMerge.result && (
                              <>
                                <span className="text-3xl font-bold text-green-600">=</span>
                                <div className="flex shadow-lg rounded-lg overflow-hidden border-2 border-green-500">
                                  {currentState.currentMerge.result.map((val, i) => (
                                    <div key={i} className="w-12 h-12 bg-green-500 flex items-center justify-center font-bold text-white text-lg border-r border-green-400 last:border-r-0">
                                      {val}
                                    </div>
                                  ))}
                                </div>
                              </>
                            )}
                          </div>
                        </div>
                      </>
                    )}

                    {currentState.phase === 'complete' && (
                      <>
                        <div className="text-4xl text-green-500">↓</div>
                        <div className="flex flex-col items-center">
                          <div className="text-sm font-semibold text-green-700 mb-2">Sorted Array</div>
                          <div className="flex shadow-2xl rounded-lg overflow-hidden border-3 border-green-600">
                            {currentState.array.map((val, i) => (
                              <div key={i} className="w-16 h-16 bg-green-500 flex items-center justify-center font-bold text-white text-xl border-r border-green-400 last:border-r-0">
                                {val}
                              </div>
                            ))}
                          </div>
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>
            ) : (
              <div className="flex flex-wrap items-end justify-center gap-6 mb-8 relative z-10">
                {currentState.array.map((value, idx) => {
                  const isComparing = currentState.comparing.includes(idx);
                  const isSwapping = currentState.swapping.includes(idx);
                  const isSorted = currentState.sorted.includes(idx);

                  const floatHeight = isSorted ? (1 - value / maxValue) * 150 : 0;
                  const balloonSize = Math.max(80, Math.min(120, 60 + (value / maxValue) * 60));

                  return (
                    <div
                      key={idx}
                      className="relative transition-all duration-700 ease-out"
                      style={{
                        transform: `translateY(-${floatHeight}px) ${isSwapping ? 'scale(1.15)' : 'scale(1)'}`,
                      }}
                    >
                      <div className="relative flex flex-col items-center">
                        <div
                          className={`relative transition-all duration-500 ${
                            isSwapping ? 'animate-bounce' : ''
                          }`}
                          style={{
                            width: `${balloonSize}px`,
                            height: `${balloonSize * 1.15}px`,
                          }}
                        >
                          <div
                            className={`absolute inset-0 rounded-full transition-all duration-500 shadow-lg ${
                              isSorted
                                ? 'bg-gradient-to-br from-green-300 via-green-400 to-green-500 border-4 border-green-600'
                                : isComparing
                                ? 'bg-gradient-to-br from-yellow-300 via-yellow-400 to-yellow-500 border-4 border-yellow-600 animate-pulse'
                                : isSwapping
                                ? 'bg-gradient-to-br from-red-400 via-pink-400 to-red-500 border-4 border-red-600'
                                : 'bg-gradient-to-br from-blue-300 via-blue-400 to-blue-500 border-4 border-blue-600'
                            }`}
                            style={{
                              borderRadius: '50% 50% 45% 45%',
                            }}
                          >
                            <div className="absolute top-4 left-4 w-8 h-8 bg-white/40 rounded-full blur-sm"></div>
                          </div>

                          <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-2xl font-bold text-white drop-shadow-lg" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.3)' }}>
                              {value}
                            </span>
                          </div>

                          <div
                            className={`absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-2 w-3 h-4 transition-colors duration-500 ${
                              isSorted
                                ? 'bg-green-600'
                                : isComparing
                                ? 'bg-yellow-600'
                                : isSwapping
                                ? 'bg-red-600'
                                : 'bg-blue-600'
                            }`}
                            style={{
                              clipPath: 'polygon(50% 0%, 0% 50%, 50% 100%, 100% 50%)',
                            }}
                          ></div>
                        </div>

                        <div
                          className={`w-0.5 transition-all duration-700 ${
                            isSorted
                              ? 'bg-green-400'
                              : isComparing
                              ? 'bg-yellow-400'
                              : isSwapping
                              ? 'bg-red-400'
                              : 'bg-blue-400'
                          }`}
                          style={{
                            height: `${80 + floatHeight}px`,
                          }}
                        ></div>

                        <div className="mt-2 text-xs text-indigo-700 font-mono bg-white/70 px-2 py-1 rounded">
                          [{idx}]
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="bg-white/80 backdrop-blur-sm rounded-xl px-6 py-3 border-2 border-indigo-200 shadow-lg">
              <p className="text-indigo-900 text-center font-medium flex items-center gap-2">
                <ArrowRight size={20} className="text-indigo-600" />
                {currentState.message}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
            <div className="flex items-center gap-2 bg-blue-50 px-3 py-2 rounded-lg border-2 border-blue-200">
              <div className="w-6 h-6 bg-gradient-to-br from-blue-300 to-blue-500 rounded-full border-2 border-blue-600"></div>
              <span className="text-indigo-900 font-medium">Unsorted</span>
            </div>
            <div className="flex items-center gap-2 bg-yellow-50 px-3 py-2 rounded-lg border-2 border-yellow-200">
              <div className="w-6 h-6 bg-gradient-to-br from-yellow-300 to-yellow-500 rounded-full border-2 border-yellow-600"></div>
              <span className="text-indigo-900 font-medium">Comparing</span>
            </div>
            <div className="flex items-center gap-2 bg-red-50 px-3 py-2 rounded-lg border-2 border-red-200">
              <div className="w-6 h-6 bg-gradient-to-br from-red-400 to-red-500 rounded-full border-2 border-red-600"></div>
              <span className="text-indigo-900 font-medium">Swapping</span>
            </div>
            <div className="flex items-center gap-2 bg-green-50 px-3 py-2 rounded-lg border-2 border-green-200">
              <div className="w-6 h-6 bg-gradient-to-br from-green-300 to-green-500 rounded-full border-2 border-green-600"></div>
              <span className="text-indigo-900 font-medium">Sorted</span>
            </div>
          </div>
        </div>

        <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border-2 border-indigo-200">
          <div className="flex items-start gap-4">
            <Info className="text-indigo-600 flex-shrink-0 mt-1" size={28} />
            <div>
              <h2 className="text-3xl font-bold text-indigo-900 mb-3">{algorithms[algorithm].name}</h2>
              <p className="text-indigo-800 mb-4 text-lg leading-relaxed">{algorithms[algorithm].description}</p>
              <div className="flex flex-wrap gap-3">
                <span className="text-sm font-mono bg-indigo-100 text-indigo-900 px-4 py-2 rounded-lg border-2 border-indigo-300">
                  {algorithms[algorithm].complexity}
                </span>
                <span className="text-sm font-medium bg-blue-100 text-blue-900 px-4 py-2 rounded-lg border-2 border-blue-300">
                  Best for: {algorithms[algorithm].bestFor}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SortingVisualizer;
